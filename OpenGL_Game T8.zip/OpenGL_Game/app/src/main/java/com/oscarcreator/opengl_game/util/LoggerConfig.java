package com.oscarcreator.opengl_game.util;

public class LoggerConfig {

    public static final boolean ON = true;

}
