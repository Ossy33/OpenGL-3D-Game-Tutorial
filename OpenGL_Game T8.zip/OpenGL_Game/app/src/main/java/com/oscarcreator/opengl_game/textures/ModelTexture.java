package com.oscarcreator.opengl_game.textures;

public class ModelTexture {

    private int textureId;

    public ModelTexture(int id){
        this.textureId = id;
    }

    public int getID() {
        return textureId;
    }
}
