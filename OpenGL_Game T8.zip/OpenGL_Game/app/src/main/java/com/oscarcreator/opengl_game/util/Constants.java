package com.oscarcreator.opengl_game.util;

/**
 * Created by Oscar on 2019-08-06.
 */
public class Constants {

	public static final boolean LOGGING = true;

	public static final int POSITION_VBO_LOCATION = 0;
	public static final int TEXTURE_VBO_LOCATION = 1;
}
